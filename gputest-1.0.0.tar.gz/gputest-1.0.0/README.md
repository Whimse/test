
# Install

  python3 -m pip install git+ssh://git@github.com/Whimse/gputest.git

# Usage

From command line:

  python3 -m gputest

From code:

  import gputest
