import __main__
import torch
import GPUtil
from tabulate import tabulate
from enum import Enum

TTY_CLEAR =                     '\033[0m'
TTY_BOLD =                      '\033[1m'
TTY_LIGHT_RED =                 '\033[91m'
TTY_LIGHT_GREEN =               '\033[92m'

GREEN = lambda s: f"{TTY_LIGHT_GREEN}{TTY_BOLD}{s}{TTY_CLEAR}"
RED =   lambda s: f"{TTY_LIGHT_RED}{TTY_BOLD}{s}{TTY_CLEAR}"
OK =    GREEN("OK")
ERROR = RED("ERROR")

CUDA_device_names = [ torch.cuda.get_device_name(dev_id) for dev_id in range(torch.cuda.device_count()) ]

gpus = GPUtil.getGPUs()
list_gpus = []
for gpu in gpus:
    # get the GPU id
    gpu_id = gpu.id
    # name of GPU
    gpu_name = gpu.name
    # get % percentage of GPU usage of that GPU
    gpu_load = f"{gpu.load*100}%"
    # get free memory in MB format
    gpu_free_memory = f"{gpu.memoryFree}MB"
    # get used memory
    gpu_used_memory = f"{gpu.memoryUsed}MB"
    # get total memory
    gpu_total_memory = f"{gpu.memoryTotal}MB"
    # get GPU temperature in Celsius
    gpu_temperature = f"{gpu.temperature} °C"
    gpu_uuid = gpu.uuid
    list_gpus.append(["\t", f"{gpu_id}: {gpu_name} ({gpu_total_memory})"]) #, "load", "free memory", "used memory", "temperature", "uuid")))

torch_info_table = [
            ["\t", "version",           torch.__version__ ],
            ["\t", "CUDA available",    OK if torch.cuda.is_available() else ERROR ],
            ["\t", "CuDNN enabled",     OK if torch.backends.cudnn.enabled else ERROR ],
            ["\t", "CUDA device count", (GREEN if torch.cuda.device_count() else RED)(torch.cuda.device_count()) ],
            ["\t", "CUDA devices",      ", ".join([ f"({id}) {name}" for id, name in enumerate(CUDA_device_names) ]) ],
]

print("")
print("----------------------------------------")
print("GPUtil:")
print(tabulate(list_gpus, tablefmt="plain"))
print("")
print("Torch:")
print(tabulate(torch_info_table, tablefmt="plain"))
print("----------------------------------------")
print("")

