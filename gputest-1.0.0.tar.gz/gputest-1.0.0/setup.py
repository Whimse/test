from setuptools import setup

setup(
  name='gputest',
  version='1.0.0',
  author='Tony',
  author_email='antonio.l.rodriguez.lopez@gmail.com',
  packages=['gputest'],
  #scripts=['bin/script1','bin/script2'],
  #url='',
  #license='LICENSE.txt',
  description='Displays GPU availability message when imported',
  long_description=open('README.md').read(),
  install_requires=[
    "gputil>=1.4.0",
    "tabulate>=0.4.2",
  ],
)
